package easy.tuto.myquizapplication;

public class QuestionAnswer {

    public static String question[] ={
            "Which company owns the android?",
            "Which one is not the programming language?",
            "What IDE is used to Build applications?",
            "What language are not used to build Android Aplicaton"
    };

    public static String choices[][] = {
            {"Google","Apple","Nokia","Samsung"},
            {"Java","Kotlin","Notepad","Python"},
            {"Notepad","Android Studio","VSCODE","Heidi Sql"},
            {"JAVA","Kotlin","C++","Indonesia"}
    };

    public static String correctAnswers[] = {
            "Google",
            "Notepad",
            "Android Studio",
            "Indonesia"
    };

}
